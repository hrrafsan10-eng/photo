# Wedding redesign
- [ ] Preserve original wedding identity and improve typography and dates.
- [ ] Source at least 210 unique Unsplash photos with unique names.
- [ ] Build event collections and a full photo viewer without number overlays.
- [ ] Verify gallery interactions and desktop/mobile presentation.