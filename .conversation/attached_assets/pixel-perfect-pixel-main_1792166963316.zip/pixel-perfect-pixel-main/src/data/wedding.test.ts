import { describe, expect, it } from 'vitest'
import { weddingDays, events } from './wedding'
import { photos } from './photos'

describe('Wedding requirements', () => {
  it('uses the specified first celebration date', () => {
    expect(weddingDays[0]).toBe('DAY 01 — 29 AUGUST 2026')
  })
  it('uses the specified second celebration date', () => {
    expect(weddingDays[1]).toBe('DAY 02 — 30 AUGUST 2026')
  })
  it('gives every photograph a unique filename', () => {
    expect(new Set(photos.map(p => p.filename)).size).toBe(photos.length)
  })
  it('gives every photograph a unique identity', () => {
    expect(new Set(photos.map(p => p.id)).size).toBe(photos.length)
  })
  it('keeps the requested event and collection structure', () => {
    expect(events.map(e => [e.title, e.collections])).toEqual([
      ['Engagement & Reception', ['Candid', 'Traditional']],
      ['Haldi', ['Candid']], ['Mehendi', ['Candid']], ['Nalangu', ['Candid']],
      ['Sangeet', ['Sangeet']], ['Traditional Events', ['Traditional']],
    ])
  })
  it('sources every photograph from Unsplash', () => {
    for (const photo of photos) expect(new URL(photo.source).hostname).toBe('unsplash.com')
  })
})