<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep wedding gallery metadata in a browser-safe data module and source downloaded photographs through asset pointers, so collections share stable identities without shipping binaries.
- Use reusable event gallery and photo viewer components for all photo entry points, so navigation and accessibility remain consistent.
